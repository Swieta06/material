package com.example.demo.controller;
import com.example.demo.payloads.request.BookRequest;
import com.example.demo.payloads.respons.ResponsData;
import com.example.demo.service.book.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/book")
public class BookController {
    @Autowired
    private BookService bookService;
    @PostMapping
    // /book
    public ResponseEntity<Object> createBuku(@RequestBody BookRequest request){
        try {
            ResponsData responsData=bookService.createBookService(request);
            return ResponseEntity.status(responsData.getStatus()).body(responsData);
        }catch (Exception e){
            return ResponseEntity.internalServerError().body(e.getMessage());

        }
       // return null;

    }
    @GetMapping("/getAll")
    public ResponseEntity<Object>getBook(@RequestParam(value = "status",defaultValue = "")Boolean status){
        try {
            ResponsData responsData=bookService.getBookService(status);
            return ResponseEntity.status(responsData.getStatus()).body(responsData);
        }catch (Exception e){
            return ResponseEntity.internalServerError().body(e.getMessage());

        }

    }
    @GetMapping("/{idBook}")
    public ResponseEntity<Object>getBookById(@PathVariable Long idBook){
        try {
            ResponsData responsData=bookService.getBookByIdService(idBook);
            return ResponseEntity.status(responsData.getStatus()).body(responsData);
        }catch (Exception e){
            return ResponseEntity.internalServerError().body(e.getMessage());

        }
       //return null;

    }
    @PutMapping("/{idBook}")
    public ResponseEntity<Object> updateBuku(@PathVariable Long idBook,@RequestBody BookRequest request) {
        try {
            ResponsData responsData = bookService.updateBookByIdService(idBook, request);
            return ResponseEntity.status(responsData.getStatus()).body(responsData);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(e.getMessage());

        }
    }
    @DeleteMapping("/{idBook}")
    public ResponseEntity<Object>deletBookById(@PathVariable Long idBook){
        try {
            ResponsData responsData=bookService.deleteBookService(idBook);
            return ResponseEntity.status(responsData.getStatus()).body(responsData);
        }catch (Exception e) {
            return ResponseEntity.internalServerError().body(e.getMessage());

        }
    }
}
