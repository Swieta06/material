package com.example.demo.service.book;


import com.example.demo.models.Book;
import com.example.demo.payloads.request.BookRequest;
import com.example.demo.payloads.respons.ResponsData;
import com.example.demo.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BookServiceImpl implements BookService{
    @Autowired
    private BookRepository bookRepository;


    @Override
    public ResponsData createBookService(BookRequest bookRequest) {
       Book book =new Book();
        if (bookRequest.getJudul()!=null){
            book.setTitel(bookRequest.getJudul());

        }
        if (bookRequest.getPenerbit()!=null){
            book.setAuthor(bookRequest.getPenerbit());
        }
        if(bookRequest.getTahun()!=null){
            book.setYear(bookRequest.getTahun());

        }
        if(bookRequest.getKetgori()!=null){
            book.setCategory(bookRequest.getKetgori());

        }
        if(bookRequest.getPengarang()!=null){
            book.setPublisher(bookRequest.getPengarang());
        }
        bookRepository.save(book);
        ResponsData responsData=new ResponsData(HttpStatus.CREATED.value(),"Success",book);
        return responsData;
    }

    @Override
    public ResponsData getBookService(Boolean status) {
        List<Book>books;
        if(status==null){
            books=bookRepository.findAll();


        }else {
            books=bookRepository.findByIsDeleted(status);

        }

                //books=bookRepository.findAll();
        return new ResponsData(HttpStatus.OK.value(), "Success",books);
    }

    @Override
    public ResponsData getBookByIdService(Long idBook) {
        Optional<Book>bookOptional=bookRepository.findById(idBook);
        ResponsData responsData;
        if(bookOptional.isPresent()){
            responsData=new ResponsData(HttpStatus.OK.value(),"Succses",bookOptional.get());



        }else {
            responsData=new ResponsData(HttpStatus.NOT_FOUND.value(), "Not found",null);
        }
        return responsData;
    }

    @Override
    public ResponsData updateBookByIdService(Long idBoook, BookRequest bookRequest) {
        Optional<Book>bookOptional=bookRepository.findById(idBoook);
        ResponsData responsData;
        //validate book
        if (bookOptional.isPresent()) {
            Book book=bookOptional.get();
            if (bookRequest.getJudul()!=null){
                book.setTitel(bookRequest.getJudul());

            }
            if (bookRequest.getPenerbit()!=null){
                book.setAuthor(bookRequest.getPenerbit());
            }
            if(bookRequest.getTahun()!=null){
                book.setYear(bookRequest.getTahun());

            }
            if(bookRequest.getKetgori()!=null){
                book.setCategory(bookRequest.getKetgori());

            }
            if(bookRequest.getPengarang()!=null){
                book.setPublisher(bookRequest.getPengarang());
            }
            bookRepository.save(book);
             responsData=new ResponsData(200,"Sucsess",book);
        }else {
            responsData=new ResponsData(404,"Not Found",null);
        }

        return responsData;
    }

    @Override
    public ResponsData deleteBookService(Long idBook) {
        Optional<Book>bookOptional=bookRepository.findById(idBook);
        ResponsData responsData;
        if(bookOptional.isPresent()){
            Book book=bookOptional.get();
        book.setIsDeleted(true);
        bookRepository.save(book);
        responsData=new ResponsData(200,"Success",null);
        }else {
            responsData=new ResponsData(404,"Not Found",null);
        }
        return responsData;
    }
}
