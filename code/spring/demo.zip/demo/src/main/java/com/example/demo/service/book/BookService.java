package com.example.demo.service.book;

import com.example.demo.payloads.request.BookRequest;
import com.example.demo.payloads.respons.ResponsData;

public interface BookService {
    ResponsData createBookService(BookRequest bookRequest);
    ResponsData getBookService(Boolean status);
    ResponsData getBookByIdService(Long idBook);
    ResponsData updateBookByIdService(Long idBoook, BookRequest request);
    ResponsData deleteBookService(Long idBook);
}
