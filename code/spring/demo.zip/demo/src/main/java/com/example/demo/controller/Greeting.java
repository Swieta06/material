package com.example.demo.controller;

import org.apache.catalina.users.SparseUserDatabase;
import org.springframework.web.bind.annotation.*;

@RestController
//@RequestMapping("/controller")
public class Greeting {
    @GetMapping("/hello")
    public String hello(@RequestParam(value = "name", defaultValue = "World") String name) {
        return String.format("Hello %s!", name);
    }
    @PostMapping("/post/{sapa}/{number}")
    public String helloPost(@PathVariable("sapa") String sapa,@PathVariable("number") Integer number){
        return "ini methode post : "+sapa +" "+number;
    }
    @PutMapping("/put")
    public String helloPut(@RequestBody String kalimat){
        return "ini dari hello post mapping "+kalimat;
    }

}
