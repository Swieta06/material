package com.example.demo.payloads.respons;

import com.example.demo.models.Book;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ResponsData {
    private Integer status;
    private String message;
    private Object data;
}
