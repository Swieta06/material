package com.example.demo.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;


import java.time.LocalDateTime;
@Entity
@Table(name = "books")
@Data
@NoArgsConstructor
public class Book {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)//auto inc
    private Long id;
    @Column(length = 100)
    private String titel;
    private String publisher;
    private String author;
    private String year;
    private  String category;
    @CreationTimestamp
    @JsonIgnore
    private LocalDateTime createdAt;
    @CreationTimestamp
    @JsonIgnore
    private LocalDateTime updatedAt;
    private Boolean isDeleted=false;

    public Book(String titel, String publisher, String author, String year, String category) {
        this.titel = titel;
        this.publisher = publisher;
        this.author = author;
        this.year = year;
        this.category = category;
    }
}
